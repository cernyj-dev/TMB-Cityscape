#include "WindowSender.hpp"

#include <fmt/format.h>

#include <Application.hpp>

void WindowSender::serializeSurface(const Surface& surface) {
    if (this->application->captures.empty()) {
        return;
    }

    this->output = this->application->captures[0]->currentImage().clone();

    for (const auto& object : surface.c_objects) {
        cv::Point2f lu1 { object->x1 * (float)this->output.cols, object->y1 * (float)this->output.rows};
        cv::Point2f lu2 { object->x2 * (float)this->output.cols, object->y2 * (float)this->output.rows};
        cv::Point2f lu3 { object->x3 * (float)this->output.cols, object->y3 * (float)this->output.rows};
        cv::Point2f lu4 { object->x4 * (float)this->output.cols, object->y4 * (float)this->output.rows};

        //std::cout << object->x1 << " " << object->y1 << "  " << object->x3 << " " << object->y3  << std::endl;
        cv::circle(output, lu1, 5, cv::Scalar(255, 255, 0), 1);
        cv::circle(output, lu2, 5, cv::Scalar(255, 255, 0), 1);
        cv::circle(output, lu3, 5, cv::Scalar(255, 255, 0), 1);
        cv::circle(output, lu4, 5, cv::Scalar(255, 255, 0), 1);

        cv::putText(output, fmt::format("{}", object->classId), lu1, cv::FONT_HERSHEY_PLAIN, 1.0, cv::Scalar(255, 255, 255));
    }
}

void WindowSender::send() {
    if (this->output.empty()) {
        return;
    }

    cv::imshow("Window", this->output);
    cv::waitKey(1);
}
