#pragma once

#include <cstdint>

class Object_Custom {
public:
    int32_t sessionId;
    int32_t classId;

    float x1;
    float y1;

    float x2;
    float y2;

    float x3;
    float y3;

    float x4;
    float y4;
};