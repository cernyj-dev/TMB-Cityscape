#pragma once

#include <Component.hpp>
#include <Surface.hpp>
#include <ArUcoDriver.hpp>

class Application;

class Sender : public Component {
public:
    virtual void serializeSurface(const Surface& surface) = 0;
    //virtual void serializeSurface(const ArUcoDriver& driver) = 0;
    virtual void send() = 0;
};