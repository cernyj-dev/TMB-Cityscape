#include "ArUcoDriver.hpp"

#include <fmt/format.h>

void ArUcoDriver::registerOptions(cxxopts::Options &options) {
    Component::registerOptions(options);
}

void ArUcoDriver::receiveOptions(const cxxopts::ParseResult& result) {
    this->parameters = cv::aruco::DetectorParameters::create();
    this->dictionary = cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_250);
}

void ArUcoDriver::processFrame(const std::vector<std::unique_ptr<Capture>>& captures) {
    for (const auto& capture : captures) {
        const cv::Mat& frame = capture->currentImage();

        cv::aruco::detectMarkers(
            frame,
            this->dictionary,
            this->markerCorners, this->markerIds,
            this->parameters,
            this->rejectedCandidates
        );

        for (size_t i = 0; i < this->markerCorners.size(); i++) {
            float x1,x2,x3 = 0;
            float y1,y2,y3= 0;

            /* Left upper corner */
            x1 = this->markerCorners[i][0].x;
            y1 = this->markerCorners[i][0].y;
            cv::Point2f lu_corner {
                x1,y1
            };

            /* Right upper upper corner */
            x2 = this->markerCorners[i][1].x;
            y2 = this->markerCorners[i][1].y;
            cv::Point2f ru_corner {
                x2,y2
            };

            x3 = (x2 - x1);
            y3 = (y2 - y1);
            cv::Point2f m_vector {
                x3,y3
            };
            // Normalize coords

            lu_corner.x  /= (float)frame.cols;
            lu_corner.y /= (float)frame.rows;
            ru_corner.x  /= (float)frame.cols;
            ru_corner.y /= (float)frame.rows;
            m_vector.x  /= (float)frame.cols;
            m_vector.y /= (float)frame.rows;

            int id = markerIds[i];

            bool found = false;
            for (const auto& object : this->surface->objects) {
                if (object->classId == id) {
                    found = true;

                    object->x = lu_corner.x;
                    object->y = lu_corner.y;

                    object->vx = ru_corner.x;
                    object->vy = ru_corner.y;
                }
            }

            if (!found) {
                auto newObject = std::make_unique<Object>();

                newObject->sessionId = this->sessionIdCounter++;
                newObject->classId = id;

                newObject->x = lu_corner.x;
                newObject->y = lu_corner.y;

                newObject->vx = ru_corner.x;
                newObject->vy = ru_corner.y;

                this->surface->objects.push_back(std::move(newObject));
            }
        }

        this->surface->objects.erase(
            std::remove_if(
                this->surface->objects.begin(),
                this->surface->objects.end(),
                [&](const std::unique_ptr<Object>& o) {
                    return std::find(markerIds.begin(), markerIds.end(), o->classId) == markerIds.end();
                }
            ),
            this->surface->objects.end()
        );
    }
}
