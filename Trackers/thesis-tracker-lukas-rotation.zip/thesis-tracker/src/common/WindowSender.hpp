#pragma once

#include <opencv2/opencv.hpp>
#include <ArUcoDriver.hpp>
#include <Sender.hpp>

class WindowSender : public Sender {
public:
    //void serializeSurface(const ArUcoDriver &driver) override;
    void serializeSurface(const Surface &surface) override;
    void send() override;

private:
    cv::Mat output;
};
