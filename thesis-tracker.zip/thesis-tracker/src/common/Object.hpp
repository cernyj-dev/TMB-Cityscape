#pragma once

#include <cstdint>

class Object {
public:
    int32_t sessionId;
    int32_t classId;

    float x;
    float y;
    float a;
};
