#include "Component.hpp"

void Component::registerOptions(cxxopts::Options& options) {
}

void Component::receiveOptions(const cxxopts::ParseResult& result) {
}