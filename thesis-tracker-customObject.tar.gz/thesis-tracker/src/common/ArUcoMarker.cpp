#include "ArUcoMarker.hpp"

//cv::Mat ArUcoMarker::image() const {
//    static cv::Ptr<cv::aruco::Dictionary> dictionary = cv::aruco::getPredefinedDictionary(cv::aruco::DICT_4X4_50);
//
//    cv::Mat markerImage;
//
//    return Marker::image();
//}
