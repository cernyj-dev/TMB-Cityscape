#pragma once

#include <opencv2/opencv.hpp>

class Marker {
public:
//    virtual cv::Mat image(uint32_t pixelSize = 128) const = 0;
};
