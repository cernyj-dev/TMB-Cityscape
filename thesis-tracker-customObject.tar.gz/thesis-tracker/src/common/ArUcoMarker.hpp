#include <opencv2/aruco.hpp>

#include "Marker.hpp"

class ArUcoMarker : public Marker {
public:
//    cv::Mat image() const override;
};
