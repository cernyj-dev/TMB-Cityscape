#include "ArUcoDriver.hpp"

#include <fmt/format.h>

void ArUcoDriver::registerOptions(cxxopts::Options &options) {
    Component::registerOptions(options);
}

void ArUcoDriver::receiveOptions(const cxxopts::ParseResult& result) {
    this->parameters = cv::aruco::DetectorParameters::create();
    this->dictionary = cv::aruco::getPredefinedDictionary(cv::aruco::DICT_6X6_50);
}

void ArUcoDriver::processFrame(const std::vector<std::unique_ptr<Capture>>& captures) {
    for (const auto& capture : captures) {
        const cv::Mat& frame = capture->currentImage();

        cv::aruco::detectMarkers(
            frame,
            this->dictionary,
            this->markerCorners, this->markerIds,
            this->parameters,
            this->rejectedCandidates
        );

        for (size_t i = 0; i < this->markerCorners.size(); i++) {
            float x = 0;
            float y = 0;

            for (const cv::Point2f& corner : this->markerCorners[i]) {
                x += corner.x;
                y += corner.y;
            }

            cv::Point2f center {
                x / (float)this->markerCorners[i].size(),
                y / (float)this->markerCorners[i].size(),
            };

            float x1,x2,x3,x4 = 0;
            float y1,y2,y3,y4 = 0;
            x1 = this->markerCorners[i][0].x;
            y1 = this->markerCorners[i][0].y;
            x2 = this->markerCorners[i][1].x;
            y2 = this->markerCorners[i][1].y;
            x3 = this->markerCorners[i][2].x;
            y3 = this->markerCorners[i][2].y;
            x4 = this->markerCorners[i][3].x;
            y4 = this->markerCorners[i][3].y;
            
            // Normalize coords
            center.x /= (float)frame.cols;
            center.y /= (float)frame.rows;

            x1 /= (float)frame.cols;
            x2 /= (float)frame.cols;
            x3 /= (float)frame.cols;
            x4 /= (float)frame.cols;

            y1 /= (float)frame.rows;
            y2 /= (float)frame.rows;
            y3 /= (float)frame.rows;
            y4 /= (float)frame.rows;

            int id = markerIds[i];


            bool found = false;
            for (const auto& object : this->surface->c_objects) {
                if (object->classId == id) {
                    found = true;

                    object->x1 = x1;
                    object->y1 = y1;
                    object->x2 = x2;
                    object->y2 = y2;
                    object->x3 = x3;
                    object->y3 = y3;
                    object->x4 = x4;
                    object->y4 = y4;
                    
                }
            }

            if (!found) {
                auto newObject = std::make_unique<Object_Custom>();

                newObject->sessionId = this->sessionIdCounter++;
                newObject->classId = id;

                newObject->x1 = x1;
                newObject->y1 = y1;
                newObject->x2 = x2;
                newObject->y2 = y2;
                newObject->x3 = x3;
                newObject->y3 = y3;
                newObject->x4 = x4;
                newObject->y4 = y4;
                    
                this->surface->c_objects.push_back(std::move(newObject));
            }
        }

        this->surface->c_objects.erase(
            std::remove_if(
                this->surface->c_objects.begin(),
                this->surface->c_objects.end(),
                [&](const std::unique_ptr<Object_Custom>& o) {
                    return std::find(markerIds.begin(), markerIds.end(), o->classId) == markerIds.end();
                }
            ),
            this->surface->c_objects.end()
        );
    }
}
